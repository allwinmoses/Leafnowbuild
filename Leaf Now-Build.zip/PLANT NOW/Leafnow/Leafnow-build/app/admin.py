from django.contrib import admin
from . models import seller,buyer,producat
# Register your models here.
admin.site.register(seller)
admin.site.register(buyer)
admin.site.register(producat)